jQuery(document).ready(function($) {
	try{
		$.removeCookie('cq_notify_close_cookie', {path: '/' });
	}catch(error){}
});
