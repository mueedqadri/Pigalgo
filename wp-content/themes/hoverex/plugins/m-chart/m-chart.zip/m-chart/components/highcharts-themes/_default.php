<?php

/**
 * Theme Name: Highcharts 4.x/5.x
 */

return array();